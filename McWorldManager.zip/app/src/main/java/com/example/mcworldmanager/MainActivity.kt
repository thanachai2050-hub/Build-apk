package com.example.mcworldmanager

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var wm: WorldManager
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private val buttons = ArrayList<Button>()
    private var cbTree: ((Uri) -> Unit)? = null
    private var cbDoc: ((Uri) -> Unit)? = null
    private var cbCreate: ((Uri) -> Unit)? = null

    private val treeL = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> deliver(u, cbTree); cbTree = null }
    private val docL = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> deliver(u, cbDoc); cbDoc = null }
    private val createL = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u -> deliver(u, cbCreate); cbCreate = null }

    private fun deliver(u: Uri?, cb: ((Uri) -> Unit)?) { if (u == null) status.text = "ยกเลิกแล้ว" else cb?.invoke(u) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        wm = WorldManager(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        root.addView(TextView(this).apply { text = "Minecraft World Manager"; textSize = 24f })
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }.also { buttons.add(it); root.addView(it) }
        btn("Export World") { exportFlow(false) }
        btn("Import .mcworld") { importFlow() }
        btn("Clone World") { cloneFlow() }
        btn("Backup World") { exportFlow(true) }
        btn("Settings") { info() }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        status = TextView(this).apply { setPadding(0, 32, 0, 0) }
        root.addView(bar); root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun info() = AlertDialog.Builder(this).setTitle("ข้อจำกัดของ Android").setMessage(
        "• Android 11+ ไม่อนุญาตให้แอปเลือกโฟลเดอร์ Android/data (ที่เก็บโลกของ Minecraft) ผ่าน SAF และไม่มีวิธีถูกต้องที่ไม่ใช้ root\n" +
        "• ทำได้: เลือกโฟลเดอร์โลกที่เข้าถึงได้ (เช่น Android 10 ลงไปที่ games/com.mojang, หรือสำเนาที่คัดลอกไว้) แล้ว Export/Clone/Backup\n" +
        "• โลกใน Android/data: ใช้ Export World ในเกม Minecraft เอง แล้วใช้แอปนี้ Import/จัดการไฟล์ .mcworld\n" +
        "• การนำเข้าเข้าเกม: เปิดไฟล์ .mcworld ด้วย Minecraft (ปุ่ม \"เปิดด้วย Minecraft\" หลัง Export)").setPositiveButton("ตกลง", null).show()

    private fun setBusy(b: Boolean) { buttons.forEach { it.isEnabled = !b }; bar.visibility = if (b) View.VISIBLE else View.GONE }
    private fun progress(m: String, pct: Int) = runOnUiThread {
        status.text = m; bar.isIndeterminate = pct < 0; if (pct >= 0) bar.progress = pct
    }

    private fun <T> work(label: String, block: suspend () -> T, done: (T) -> Unit) {
        setBusy(true)
        lifecycleScope.launch {
            try { done(withContext(Dispatchers.IO) { block() }) }
            catch (e: CancellationException) { throw e }
            catch (e: Throwable) { status.text = "$label ไม่สำเร็จ: " + human(e) }
            finally { setBusy(false) }
        }
    }

    private fun human(e: Throwable): String = when {
        e is WorldException -> e.message ?: "เกิดข้อผิดพลาด"
        e is SecurityException -> "ไม่มีสิทธิ์เข้าถึงตำแหน่งนี้ กรุณาเลือกโฟลเดอร์/ไฟล์ใหม่"
        e is IOException && (e.message ?: "").contains("ENOSPC") -> "พื้นที่จัดเก็บไม่เพียงพอ"
        e is IOException -> "อ่าน/เขียนไฟล์ไม่ได้ หรือที่จัดเก็บไม่พร้อมใช้งาน"
        else -> "เกิดข้อผิดพลาดที่ไม่คาดคิด"
    }

    private fun tree(u: Uri) = DocumentFile.fromTreeUri(this, u)
    private fun pickTree(msg: String, cb: (Uri) -> Unit) { status.text = msg; cbTree = cb; treeL.launch(null) }

    private fun exportFlow(backup: Boolean) = pickTree("เลือกโฟลเดอร์ของโลก") { t ->
        val src = tree(t)
        if (src == null || !wm.isWorld(src)) { status.text = "โฟลเดอร์นี้ไม่ใช่โลก Minecraft Bedrock (ต้องมี level.dat และ db/)"; return@pickTree }
        val base = wm.safe(wm.worldName(src))
        val ts = SimpleDateFormat("yyyy-MM-dd_HHmmss", Locale.US).format(Date())
        status.text = "เลือกที่บันทึกไฟล์"
        cbCreate = { dest ->
            val label = if (backup) "Backup" else "Export"
            work(label, { wm.export(src, dest, ::progress) }) {
                status.text = "$label สำเร็จ"
                AlertDialog.Builder(this).setTitle("$label สำเร็จ").setMessage(wm.safe(base))
                    .setPositiveButton("เปิดด้วย Minecraft") { _, _ -> openWith(dest) }.setNegativeButton("ปิด", null).show()
            }
        }
        createL.launch(if (backup) "${base}_$ts.mcworld" else "$base.mcworld")
    }

    private fun openWith(u: Uri) = try {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/octet-stream")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "เปิดด้วย"))
    } catch (e: ActivityNotFoundException) { status.text = "ไม่พบแอปที่เปิดไฟล์นี้ได้" }

    private fun importFlow() {
        status.text = "เลือกไฟล์ .mcworld"
        cbDoc = { f ->
            val base = (DocumentFile.fromSingleUri(this, f)?.name ?: "World").removeSuffix(".mcworld")
            pickTree("เลือกโฟลเดอร์ปลายทาง (เช่น minecraftWorlds ถ้าเข้าถึงได้)") { t ->
                val parent = tree(t)
                if (parent == null) status.text = "เลือกโฟลเดอร์ไม่ได้" else
                    work("Import", { wm.import(f, parent, base, ::progress) }) { status.text = "Import สำเร็จ: $it" }
            }
        }
        docL.launch(arrayOf("application/octet-stream", "application/zip", "*/*"))
    }

    private fun cloneFlow() = pickTree("เลือกโฟลเดอร์ของโลกที่จะ Clone") { t ->
        val src = tree(t)
        if (src == null || !wm.isWorld(src)) { status.text = "โฟลเดอร์นี้ไม่ใช่โลก Minecraft Bedrock"; return@pickTree }
        val et = EditText(this).apply { setText(wm.worldName(src) + " Copy") }
        AlertDialog.Builder(this).setTitle("ชื่อโลกใหม่").setView(et).setNegativeButton("ยกเลิก", null)
            .setPositiveButton("ถัดไป") { _, _ ->
                val nn = et.text.toString().trim()
                if (nn.isEmpty()) { status.text = "กรุณาใส่ชื่อ"; return@setPositiveButton }
                pickTree("เลือกโฟลเดอร์ปลายทางของสำเนา") { d ->
                    val parent = tree(d)
                    if (parent == null) status.text = "เลือกโฟลเดอร์ไม่ได้" else
                        work("Clone", { wm.clone(src, parent, nn, ::progress) }) { status.text = "Clone สำเร็จ: $nn" }
                }
            }.show()
    }
}
