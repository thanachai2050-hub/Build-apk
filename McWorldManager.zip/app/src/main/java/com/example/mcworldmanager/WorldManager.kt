package com.example.mcworldmanager

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.BufferedOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class WorldException(msg: String) : Exception(msg)
typealias Progress = (String, Int) -> Unit   // percent < 0 = indeterminate

/** World Manager + File Access + ZIP layer (เก็บในไฟล์เดียวเพื่อความกระชับ แยกเป็นคลาสได้ภายหลัง) */
class WorldManager(ctx: Context) {
    private val cr = ctx.contentResolver
    private val mime = "application/octet-stream" // กัน SAF เติมนามสกุลเอง

    fun isWorld(d: DocumentFile) = d.findFile("level.dat")?.isFile == true && d.findFile("db")?.isDirectory == true

    fun worldName(d: DocumentFile): String {
        val n = try {
            d.findFile("levelname.txt")?.let { f -> cr.openInputStream(f.uri)?.use { it.readBytes().toString(Charsets.UTF_8).trim() } }
        } catch (e: Exception) { null }
        return if (n.isNullOrEmpty()) d.name ?: "World" else n
    }

    fun safe(n: String) = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "World" }

    private fun walk(d: DocumentFile, prefix: String, out: MutableList<Pair<String, DocumentFile>>) {
        for (c in d.listFiles()) {
            val n = c.name ?: continue
            if (c.isDirectory) walk(c, "$prefix$n/", out) else out.add((prefix + n) to c)
        }
    }

    private fun dirFor(root: DocumentFile, path: String, cache: HashMap<String, DocumentFile>): DocumentFile {
        val i = path.lastIndexOf('/')
        if (i < 0) return root
        val dp = path.substring(0, i)
        cache[dp]?.let { return it }
        var cur = root; var acc = ""
        for (part in dp.split('/')) {
            acc = if (acc.isEmpty()) part else "$acc/$part"
            cur = cache[acc] ?: (cur.findFile(part)?.takeIf { it.isDirectory } ?: cur.createDirectory(part)
                ?: throw WorldException("สร้างโฟลเดอร์ปลายทางไม่สำเร็จ")).also { cache[acc] = it }
        }
        return cur
    }

    private fun writeFile(dir: DocumentFile, name: String, input: InputStream) {
        val f = dir.createFile(mime, name) ?: throw WorldException("สร้างไฟล์ปลายทางไม่สำเร็จ")
        (cr.openOutputStream(f.uri) ?: throw WorldException("เขียนไฟล์ปลายทางไม่ได้")).use { input.copyTo(it) }
    }

    /** EXPORT / BACKUP: โฟลเดอร์ world -> .mcworld (level.dat อยู่ที่ root ของ zip) */
    suspend fun export(src: DocumentFile, dest: Uri, p: Progress) {
        if (!isWorld(src)) throw WorldException("โฟลเดอร์นี้ไม่ใช่โลก Minecraft Bedrock (ไม่พบ level.dat หรือ db/)")
        p("กำลังอ่านโลก...", -1)
        val files = ArrayList<Pair<String, DocumentFile>>()
        walk(src, "", files)
        try {
            val os = cr.openOutputStream(dest, "w") ?: throw WorldException("ไม่สามารถเขียนไฟล์ปลายทางได้")
            ZipOutputStream(BufferedOutputStream(os)).use { zip ->
                files.forEachIndexed { i, (path, f) ->
                    currentCoroutineContext().ensureActive()
                    zip.putNextEntry(ZipEntry(path))
                    (cr.openInputStream(f.uri) ?: throw WorldException("ไม่สามารถอ่านไฟล์ $path ของโลกได้")).use { it.copyTo(zip) }
                    zip.closeEntry()
                    p("กำลังบีบอัด...", (i + 1) * 100 / files.size)
                }
                p("กำลังสร้างไฟล์ .mcworld...", 100)
            }
        } catch (e: Throwable) {
            runCatching { DocumentsContract.deleteDocument(cr, dest) } // ลบเฉพาะไฟล์ผลลัพธ์ที่เพิ่งสร้างและไม่สมบูรณ์
            throw e
        }
    }

    /** IMPORT: .mcworld -> โฟลเดอร์ใหม่ใน parent (ไม่ overwrite; ชื่อซ้ำจะต่อท้าย (2)) คืนชื่อโฟลเดอร์ */
    suspend fun import(src: Uri, parent: DocumentFile, baseName: String, p: Progress): String {
        p("กำลังตรวจสอบไฟล์...", -1)
        var hasLevel = false; var hasDb = false
        try {
            ZipInputStream(cr.openInputStream(src) ?: throw WorldException("เปิดไฟล์ไม่ได้")).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name.replace('\\', '/')
                    if (n.startsWith("/") || n.split('/').any { it == ".." }) throw WorldException("ไฟล์มีเส้นทางที่ไม่ปลอดภัย จึงไม่นำเข้า")
                    if (n == "level.dat") hasLevel = true
                    if (n.startsWith("db/")) hasDb = true
                    e = z.nextEntry
                }
            }
        } catch (e: ZipException) { throw WorldException("ไฟล์ .mcworld เสียหรือไม่ใช่ไฟล์ zip") }
        if (!hasLevel || !hasDb) throw WorldException("ไฟล์นี้ไม่ใช่โลก Minecraft (ไม่พบ level.dat หรือ db/ ที่ root)")

        var name = safe(baseName); var i = 2
        while (parent.findFile(name) != null) { name = "${safe(baseName)} ($i)"; i++ }
        val root = parent.createDirectory(name) ?: throw WorldException("สร้างโฟลเดอร์ปลายทางไม่ได้ (ไม่มีสิทธิ์?)")
        val cache = HashMap<String, DocumentFile>()
        try {
            var count = 0
            ZipInputStream(cr.openInputStream(src) ?: throw WorldException("เปิดไฟล์ไม่ได้")).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    currentCoroutineContext().ensureActive()
                    if (!e.isDirectory) {
                        val n = e.name.replace('\\', '/')
                        writeFile(dirFor(root, n, cache), n.substringAfterLast('/'), z)
                        p("กำลังนำเข้า... ($count ไฟล์)", -1); count++
                    }
                    e = z.nextEntry
                }
            }
        } catch (e: Throwable) {
            root.delete() // ลบเฉพาะโฟลเดอร์ที่เราเพิ่งสร้างและไม่สมบูรณ์
            throw e
        }
        return name
    }

    /** CLONE: คัดลอกไปโฟลเดอร์ใหม่ + ตั้ง levelname.txt ใหม่ ต้นฉบับอ่านอย่างเดียว */
    suspend fun clone(src: DocumentFile, parent: DocumentFile, newName: String, p: Progress) {
        if (!isWorld(src)) throw WorldException("โฟลเดอร์นี้ไม่ใช่โลก Minecraft Bedrock")
        val nm = safe(newName)
        if (parent.findFile(nm) != null) throw WorldException("มีโลกชื่อ \"$nm\" อยู่แล้ว กรุณาใช้ชื่ออื่น")
        if (parent.uri == src.uri) throw WorldException("ปลายทางต้องไม่ใช่โฟลเดอร์ของโลกต้นฉบับ")
        p("กำลังอ่านโลก...", -1)
        val files = ArrayList<Pair<String, DocumentFile>>(); walk(src, "", files)
        val root = parent.createDirectory(nm) ?: throw WorldException("สร้างโฟลเดอร์ปลายทางไม่ได้")
        val cache = HashMap<String, DocumentFile>()
        try {
            files.forEachIndexed { i, (path, f) ->
                currentCoroutineContext().ensureActive()
                if (path != "levelname.txt")
                    writeFile(dirFor(root, path, cache), path.substringAfterLast('/'),
                        cr.openInputStream(f.uri) ?: throw WorldException("อ่านไฟล์ $path ไม่ได้"))
                p("กำลังคัดลอก...", (i + 1) * 100 / files.size)
            }
            writeFile(root, "levelname.txt", newName.trim().byteInputStream())
            val copied = ArrayList<Pair<String, DocumentFile>>(); walk(root, "", copied)
            if (copied.size != files.size) throw WorldException("ตรวจสอบสำเนาไม่ผ่าน (จำนวนไฟล์ไม่ตรง)")
        } catch (e: Throwable) { root.delete(); throw e }
    }
}
